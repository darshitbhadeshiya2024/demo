from django.shortcuts import render
from .serializer import (
    registerSerializer,
    loginSerializer,
    productserializer,
    cartSerializer,
    viewCartSerializer,
    oderSerializer,
    viewProfileSerializer,
    updateProfileSerializer,
    updatePasswordSerializer,
)
from rest_framework import generics
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
import logging
from .models import product, cartItem, order, User
from django.db.models import Q

logger = logging.getLogger("django")


User = get_user_model()


# manually generates token
def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        # "refresh": str(refresh),
        "access": str(refresh.access_token),
    }


# Create your views here.


class signup(APIView):
    def post(self, request, format=None):
        serial = registerSerializer(data=request.data)
        if serial.is_valid(raise_exception=True):
            user = serial.save()
            user.create = request.user
            user.modefied = request.user
            user.set_password(request.data["password"])
            user.save()
            return Response(
                {"massge": "User create succefully"}, status=status.HTTP_201_CREATED
            )
        return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)


class login(APIView):
    def post(self, request, format=None):
        serializer = loginSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            username = serializer.data.get("username")
            password = serializer.data.get("password")
            user = authenticate(username=username, password=password)

            if user is not None:
                token = get_tokens_for_user(user)

                logger.info(f"New user logged in {user}")
                return Response(
                    {
                        "msg": "Login Success",
                        "token": token,
                    },
                    status=status.HTTP_200_OK,
                )
            else:
                return Response(
                    {
                        "errors": {
                            "non_field_errors": ["username or password is not valid"]
                        }
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
        return Response(
            {"errors": {"errors": ["username or password is not valid"]}},
            status=status.HTTP_404_NOT_FOUND,
        )


class ProductAdd(APIView):
    def post(self, request, format=None):
        stproduct = productserializer(data=request.data)
        if stproduct.is_valid():
            stproduct.save()
            return Response(
                {"massage": "product created"},
                status=status.HTTP_201_CREATED,
            )
        return Response(
            {"massage": stproduct.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


class ProductList(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = product.objects.all()
        serializer = productserializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class Add_Cart(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):

        try:
            data = request.POST.copy()
            data["user"] = request.user.id

            Product = request.data.get("product")
            productDelitel = product.objects.filter(pk=Product).first()
            print(productDelitel)
            data["price"] = productDelitel.price
            data["product_name"] = productDelitel.name
            cart = cartItem.objects.filter(
                user=request.user.id, product=Product, order__isnull=True
            ).first()

            if cart is not None:
                cart.quantity += int(request.data.get("quantity"))
                cart.save()
                return Response(
                    {"massage": "quantity add"}, status=status.HTTP_201_CREATED
                )
            else:

                cart = cartSerializer(data=data)
                if cart.is_valid(raise_exception=True):
                    cart.save()
                    return Response(
                        {"massage": "Item added"}, status=status.HTTP_201_CREATED
                    )

        except Exception as e:
            return Response({"message": str(e)}, status=status.HTTP_404_NOT_FOUND)


class viewCart(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, formate=None):
        cart = cartItem.objects.filter(user_id=request.user.id, order__isnull=True)
        serializer = viewCartSerializer(cart, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


# class placeOder(APIView):
#     permission_classes = [IsAuthenticated]

#     def post(self, request):
#         data = request.POST.copy()
#         data["user"] = request.user.id
#         cart = cartItem.objects.filter(user=request.user.id, order__isnull=True)
#         total_price = sum(i.product.price * i.quantity for i in cart)
#         orders = order.objects.create(user=request.user, total_price=total_price)
#         serializer = oderSerializer(orders)
#         return Response(serializer.data, status=status.HTTP_200_OK)


####################################################################################################
class placeOder(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.POST.copy()
        print(request.POST["cart_id"])
        data["user"] = request.user.id
        cart = cartItem.objects.filter(
            user=request.user.id, order__isnull=True, id=request.POST["cart_id"]
        ).first()
        if cart is not None:
            total_price = cart.product.price * cart.quantity
            data["total_price"] = total_price
            serializer = oderSerializer(data=data)
            if serializer.is_valid(raise_exception=True):
                serializer = serializer.save()
                order = serializer
                cart.order = order
                cart.save()
                return Response(
                    {"message": "Order added successfully"}, status=status.HTTP_200_OK
                )
        else:
            return Response(
                {"message": "Please add item in cart"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class Get_oder(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = request.POST.copy()
        data["user"] = request.user.id
        Order = order.objects.filter(
            user=request.user
        )  # ~Q from django.db.models import Q not equal to login sivsy badhha data get
        serial = oderSerializer(Order, many=True)
        if serial:
            return Response({"data": serial.data}, status=status.HTTP_200_OK)
        else:
            return Response({"message": "error"}, status=status.HTTP_400_BAD_REQUEST)


class viewProfile(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = request.POST.copy()
        data["user"] = request.user.id
        profile = User.objects.get(username=request.user)
        view = viewProfileSerializer(profile)
        if view:
            return Response({"data": view.data}, status=status.HTTP_200_OK)
        else:
            return Response({"message": "error"}, status=status.HTTP_400_BAD_REQUEST)


class userProfile(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            user = User.objects.get(pk=request.user.id)
            profile = updateProfileSerializer(user)
            return Response(profile.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"massege": e}, status=status.HTTP_400_BAD_REQUEST)


class updateProfile(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request):
        user = User.objects.get(id=request.user.id)
        view = updateProfileSerializer(instance=user, data=request.data)
        if view.is_valid(raise_exception=True):
            view.save()
            return Response("Updated successfully", status=status.HTTP_202_ACCEPTED)
        return Response("update", status=status.HTTP_404_NOT_FOUND)


class updatePassword(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, queryset=None):
        return self.request.user

    def put(self, request):
        self.object = self.get_object()
        serializer = updatePasswordSerializer(data=request.data)

        if serializer.is_valid():
            # Check old password
            old_password = serializer.data.get("password")
            if not self.object.check_password(old_password):
                return Response(
                    {"password": ["Wrong password."]},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            # set_password also hashes the password that the user will get
            self.object.set_password(serializer.data.get("new_password"))
            self.object.save()
            return Response(
                {"password": ["Update password."]}, status=status.HTTP_204_NO_CONTENT
            )

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
