from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import product, cartItem, order
from django.contrib.auth.password_validation import validate_password

User = get_user_model()


class registerSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True)
    first_name = serializers.CharField(required=True, trim_whitespace=True)
    last_name = serializers.CharField(required=True, trim_whitespace=True)

    class Meta:
        model = User
        fields = ["username", "password", "first_name", "last_name", "email"]


class loginSerializer(serializers.ModelSerializer):
    username = serializers.CharField(max_length=100)

    class Meta:
        model = User
        fields = ["id", "username", "password"]


class productserializer(serializers.ModelSerializer):
    class Meta:
        model = product
        fields = "__all__"


class cartSerializer(serializers.ModelSerializer):
    class Meta:
        model = cartItem
        fields = ["user", "quantity", "product", "price", "product_name"]

    def get_total_price(self, obj):
        return obj.quantity * obj.product.price


class viewCartSerializer(serializers.ModelSerializer):
    productDetails = serializers.SerializerMethodField()

    def get_productDetails(self, obj):
        productInfo = product.objects.filter(pk=obj.product_id).values()
        return productInfo

    class Meta:
        model = cartItem
        fields = ["id", "product_name", "quantity", "user", "productDetails"]


class oderSerializer(serializers.ModelSerializer):
    items = cartSerializer(many=True, read_only=True)
    cartItem = serializers.SerializerMethodField()

    def get_cartItem(self, obj):
        cart = cartItem.objects.filter(order_id=obj.id).values(
            "product_name", "quantity", "price"
        )
        return cart

    class Meta:
        model = order
        fields = "__all__"

    def get_total_price(self, obj):
        return sum(item.item.price * item.quantity for item in obj.items.all())


class viewProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "first_name", "last_name", "email"]


class updateProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email"]


class updatePasswordSerializer(serializers.ModelSerializer):
    password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)
    confirm_password = serializers.CharField(required=True)

    def validate_new_password(self, value):
        validate_password(value)
        return value

    class Meta:
        model = User
        fields = ["password", "new_password", "confirm_password"]
