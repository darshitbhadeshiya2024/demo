from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class product(models.Model):
    name = models.CharField(max_length=20)
    image = models.ImageField()
    discripitons = models.TextField()
    price = models.BigIntegerField()

    def __str__(self) -> str:
        return self.name


class order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False, blank=False)
    total_price = models.BigIntegerField()


class cartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=False, blank=False)
    product = models.ForeignKey(
        product, on_delete=models.CASCADE, null=False, blank=False
    )
    product_name = models.CharField(max_length=20)
    quantity = models.PositiveIntegerField(null=False, blank=False)
    price = models.BigIntegerField(null=False, blank=False)
    order = models.ForeignKey(order, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.quantity} x {self.product}"
