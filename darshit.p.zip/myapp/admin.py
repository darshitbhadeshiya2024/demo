from django.contrib import admin
from .models import product

# Register your models here.
#admin site username=admin password=12345
class productadmin(admin.ModelAdmin):
    list_display=["id","name","image","discripitons","price"]
    
admin.site.register(product)