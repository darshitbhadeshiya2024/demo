from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from myapp.views import (
    signup,
    login,
    ProductAdd,
    ProductList,
    Add_Cart,
    viewCart,
    placeOder,
    Get_oder,
    viewProfile,
    updateProfile,
    userProfile,
    updatePassword,
)

urlpatterns = [
    path("signup", signup.as_view()),
    path("login", login.as_view()),
    path("product", ProductAdd.as_view()),
    path("productlist", ProductList.as_view()),
    path("addcart", Add_Cart.as_view()),
    path("viewcart", viewCart.as_view()),
    path("placeoder", placeOder.as_view()),
    path("getoder", Get_oder.as_view()),
    path("viewprofile", viewProfile.as_view()),
    path("updateprofile", updateProfile.as_view()),
    path("userprofile", userProfile.as_view()),
    path("updatepassword", updatePassword.as_view()),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    urlpatterns += staticfiles_urlpatterns()
